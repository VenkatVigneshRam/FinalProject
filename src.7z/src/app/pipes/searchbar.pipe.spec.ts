import { SearchbarPipe } from './searchbar.pipe';

describe('SearchbarPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchbarPipe();
    expect(pipe).toBeTruthy();
  });
});
