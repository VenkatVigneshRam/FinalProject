import { ReviewPipe } from './review.pipe';

describe('ReviewPipe', () => {
  it('create an instance', () => {
    const pipe = new ReviewPipe();
    expect(pipe).toBeTruthy();
  });
});
