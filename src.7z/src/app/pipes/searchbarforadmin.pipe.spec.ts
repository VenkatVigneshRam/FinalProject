import { SearchbarforadminPipe } from './searchbarforadmin.pipe';

describe('SearchbarforadminPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchbarforadminPipe();
    expect(pipe).toBeTruthy();
  });
});
