import { YearfilterPipe } from './yearfilter.pipe';

describe('YearfilterPipe', () => {
  it('create an instance', () => {
    const pipe = new YearfilterPipe();
    expect(pipe).toBeTruthy();
  });
});
