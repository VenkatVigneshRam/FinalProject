import { GenrefilterPipe } from './genrefilter.pipe';

describe('GenrefilterPipe', () => {
  it('create an instance', () => {
    const pipe = new GenrefilterPipe();
    expect(pipe).toBeTruthy();
  });
});
