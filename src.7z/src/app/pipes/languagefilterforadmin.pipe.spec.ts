import { LanguagefilterforadminPipe } from './languagefilterforadmin.pipe';

describe('LanguagefilterforadminPipe', () => {
  it('create an instance', () => {
    const pipe = new LanguagefilterforadminPipe();
    expect(pipe).toBeTruthy();
  });
});
