import { LanguagefilterPipe } from './languagefilter.pipe';

describe('LanguagefilterPipe', () => {
  it('create an instance', () => {
    const pipe = new LanguagefilterPipe();
    expect(pipe).toBeTruthy();
  });
});
