export const slideshow={
    img:{
        width:"100%",
        height:"560px"
    }
}