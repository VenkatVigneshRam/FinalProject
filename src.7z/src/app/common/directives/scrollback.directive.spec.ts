import { ScrollbackDirective } from './scrollback.directive';

describe('ScrollbackDirective', () => {
  it('should create an instance', () => {
    const directive = new ScrollbackDirective();
    expect(directive).toBeTruthy();
  });
});
